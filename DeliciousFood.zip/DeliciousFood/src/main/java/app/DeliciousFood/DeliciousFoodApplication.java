package app.DeliciousFood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliciousFoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliciousFoodApplication.class, args);
	}

}
